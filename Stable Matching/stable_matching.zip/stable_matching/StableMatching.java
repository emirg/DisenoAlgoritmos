import java.util.*;
import java.io.*;
import java.io.IOException;

public class StableMatching {
  public void readFile(String filePath) {
    BufferedReader fileReader = null;

    try {
			String currentLineString = null;
			String[] currentLineArray = null;

			fileReader = new BufferedReader(new FileReader(filePath));

			// leo linea a linea para leer la persona y sus preferencias.
      // 'persona' puede ser tanto hombre como mujer
			while ((currentLineString = fileReader.readLine()) != null) {

				// separo la linea por el delimitador
				currentLineArray = currentLineString.split(",");
				int numberOfPeople = currentLineArray.length - 1;
				String person = currentLineArray[0];

        //
        // TODO : Guardar 'person' (puede ser hombre o mujer) y sus preferencias
        //
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fileReader != null) {
					// close reader, good practice
					fileReader.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
  }

  public void resolv() {
    // TODO : Resolver el problema de asignaciones estables
  }

  public void show() {
    // TODO : Imprimir por pantalla los resultados.
  }
}
